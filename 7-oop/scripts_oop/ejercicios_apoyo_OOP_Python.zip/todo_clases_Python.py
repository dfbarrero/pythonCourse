import math
print(type(math))
a = 2
print(type(a))
b = 2.3
print(type(b))
c = lambda x: x+2
print(type(c))
lista = [2, "hola"]
print(type(lista))
lista.append(4)
print(lista)
print(lista.pop())
tupla = (2, "hola")
print(type(tupla))
cadena = "hola"
print(type(cadena))
print("Y todo lo demás...")